#!/bin/bash
set -euo pipefail

# Input files
HTF_FILE="/SAN/ugi/plant_genom/jiajucui/4_mapping_to_pseudomonas/tailocin_2024_TF_Tapemeasure/2025_summer_paperfig_m57/results/step3_combine/form57_h36_HTF_bykmer_tmp_addthe2modernbymapping.txt"
BINARY_FILE="/SAN/ugi/plant_genom/jiajucui/4_mapping_to_pseudomonas/tailocin_2024_TF_Tapemeasure/2025_summer_paperfig_m57/results/step2_Oantigengenes/espE2_rescue/fish_historical/final_sixgenes_withm57_h36_epsE2rescued_binary_matrix.tsv"
ESP_FASTA_FILE="/SAN/ugi/plant_genom/jiajucui/4_mapping_to_pseudomonas/tailocin_2024_TF_Tapemeasure/2025_summer_paperfig_m57/results/step2_Oantigengenes/espE2_rescue/checkespE2_57m/final_afterexpasy/completeopenframe.39fasta.txt"
OUTFILE="/SAN/ugi/plant_genom/jiajucui/4_mapping_to_pseudomonas/tailocin_2024_TF_Tapemeasure/2025_summer_paperfig_m57/results/step3_combine/combined_HTF_oantigen_m57_h36_needOantigenfivegenePAin2modern.txt"

wd is  /SAN/ugi/plant_genom/jiajucui/4_mapping_to_pseudomonas/tailocin_2024_TF_Tapemeasure/2025_summer_paperfig_m57/results/step2_Oantigengenes/espE2_rescue/fish_historical/using39m_espE2fasta/mappings/
# Define output file
output_file="h15_espE2_length.txt"
> "$output_file"

# Loop over all _mapped.paf files except PL0235
for paf in *_mapped.paf; do
    sample=$(basename "$paf" _mapped.paf)
    [[ "$sample" == "PL0235" ]] && continue

    # Extract the second line and grab the 12th column (length), i manually checked each file, found PL0001 has two hits, 4740 and p25.C11 half, so its 4740, and PL0235 has multiple hits to 4740 and 4827 so leave it, others are pure to one length
    length=$(awk 'NR==2 {print $7}' "$paf")

    echo -e "${sample}\t${length}" >> "$output_file"
done

echo "✅ Output written to: $output_file"


# Gene list
genes=(WfgD rmlC_1 tagG_1 tagH_1 spsA m57_espE2_rescued)

# Temp folder
mkdir -p tmp_gene_matrix

# Split binary matrix by gene
for gene in "${genes[@]}"; do
    awk -v g="$gene" -F"\t" 'NR==1{for(i=2;i<=NF;i++) header[i]=$i} $1==g {for(i=2;i<=NF;i++) print header[i]"\t"$i}' "$BINARY_FILE" > "tmp_gene_matrix/${gene}.tsv"
done

# Parse espE2 length and presence using soft match
awk '
    /^>/ {
        if (seq != "") {
            print id "\t1\t" length(seq);
        }
        id = substr($1, 2);
        seq = "";
        next;
    }
    {
        seq = seq $0;
    }
    END {
        if (seq != "") {
            print id "\t1\t" length(seq);
        }
    }
' "$ESP_FASTA_FILE" > espE2_info.tsv

# Output header
echo -e "sample\tHTF_haplotype\tHTFgroup_Oantigen_PA\twfgD_PA\trmlC1_PA\ttagG1_PA\ttagH1_PA\tspsA_PA\tespE2_PA\tespE2length\tnote" > "$OUTFILE"

# Read HTF table
tail -n +2 "$HTF_FILE" | while IFS=$'\t' read -r sample htf _; do
    obc="NA"
    [[ "$htf" == *"1830"* || "$htf" == *"1383"* ]] && obc="OBC_absent"
    [[ "$htf" == *"1803"* || "$htf" == *"1245"* ]] && obc="OBC_present"

    # First columns: sample, HTF, OBC group
    row="$sample\t$htf\t$obc"

    # Gene binary values
    for gene in "${genes[@]}"; do
        val=$(awk -v s="$sample" '$1 == s {print $2}' "tmp_gene_matrix/${gene}.tsv")
        row+="\t${val:-0}"
    done
    
    # If sample is p1.G2 or p23.B2, override first 5 gene values with NA
    
    espE2_PA_val=$(echo -e "$row" | awk -F'\t' '{print $(NF)}')
    # espE2 length via soft match
    esp_line=$(awk -v s="$sample" '$1 ~ s' espE2_info.tsv | head -n1)
    esp_length=$(echo "$esp_line" | cut -f3)
    # Set length to NA if espE2_PA is NA or missing
    [[ "$espE2_PA_val" == "NA" || -z "$espE2_PA_val" ]] && esp_length="NA"
    row+="\t${esp_length:-0}"
 
    # Add empty note
    row+="\t"

    echo -e "$row"
done >> "$OUTFILE"

echo "✅ Combined summary written to: $OUTFILE"
