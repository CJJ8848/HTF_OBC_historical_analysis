#PL0240
#visualize with igv
#bam
cd /SAN/ugi/plant_genom/jiajucui/tailocin_info/mydata_LPSgenesPA/sh/method1_cov_dep
 
samtools view -b /SAN/ugi/plant_genom/jiajucui/4_mapping_to_pseudomonas/2024_413_but280withnsqs10_233_HB37_ps/PL0240.mapped_to_Pseudomonas.dd.q20.bam '30' > PL0240_contig30.bam
#ref contig30
samtools faidx reference.fasta "contig_30" > contig30.fasta

